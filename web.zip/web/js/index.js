window.calendar = Calendar.setup({
    cont:"calendar",
    weekNumbers:false,
    selectionType: Calendar.SEL_SINGLE
});